'use client';

import { useEffect } from 'react';
import { Sparkles, RefreshCw } from 'lucide-react';

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error('ORRA Global Error:', error);
    // Auto-clear corrupted localStorage on crash
    try {
      localStorage.removeItem('aura-storage');
      console.warn('Auto-cleared aura-storage after global error');
    } catch {}
  }, [error]);

  return (
    <html lang="en" className="dark">
      <body className="bg-[#050505] antialiased">
        <div className="min-h-screen bg-[#050505] flex items-center justify-center p-4">
          <div className="text-center max-w-md">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-600 to-fuchsia-600 shadow-lg shadow-violet-500/30 mb-4">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-xl font-bold text-white mb-2">Something went wrong</h2>
            <p className="text-slate-400 text-sm mb-1">ORRA encountered an error.</p>
            {error?.message && (
              <p className="text-slate-500 text-xs mb-4 font-mono truncate max-w-xs mx-auto">{error.message}</p>
            )}
            <div className="flex flex-col gap-2 items-center">
              <button
                onClick={() => {
                  try { localStorage.removeItem('aura-storage'); } catch {}
                  reset();
                }}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white font-bold text-sm flex items-center gap-2"
              >
                <RefreshCw className="w-4 h-4" /> Reload ORRA
              </button>
              <button
                onClick={() => window.location.href = '/'}
                className="text-slate-500 text-xs hover:text-white transition-colors"
              >
                Go to home page
              </button>
            </div>
          </div>
        </div>
      </body>
    </html>
  );
}

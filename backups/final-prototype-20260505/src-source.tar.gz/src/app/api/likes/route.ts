import { NextRequest, NextResponse } from "next/server";
import { db, serializedTransaction, writeQueue } from "@/lib/db";
import { requireAuth } from "@/lib/auth-helpers";

export const dynamic = 'force-dynamic';

const TOKEN_AWARDS: Record<string, { tokens: number; xp: number; action: string }> = {
  post: { tokens: 1, xp: 2, action: "like_post" },
  reel: { tokens: 1, xp: 2, action: "like_reel" },
  danceEntry: { tokens: 1, xp: 2, action: "like_dance_entry" },
  hubPost: { tokens: 1, xp: 2, action: "like_hub_post" },
};

const LIKES_COUNT_FIELDS: Record<string, { model: string; field: string }> = {
  post: { model: "post", field: "likesCount" },
  reel: { model: "reel", field: "likesCount" },
  danceEntry: { model: "danceEntry", field: "likesCount" },
  hubPost: { model: "hubPost", field: "likesCount" },
};

// POST /api/likes - Toggle like
export async function POST(req: NextRequest) {
  try {
    const auth = await requireAuth();
    if (auth.response) return auth.response;

    const body = await req.json();
    const { targetId, targetType } = body;

    if (!targetId || !targetType) {
      return NextResponse.json(
        { success: false, error: "targetId and targetType are required" },
        { status: 400 }
      );
    }

    const validTypes = ["post", "reel", "danceEntry", "hubPost", "comment"];
    if (!validTypes.includes(targetType)) {
      return NextResponse.json(
        { success: false, error: `Invalid targetType. Must be one of: ${validTypes.join(", ")}` },
        { status: 400 }
      );
    }

    // Use serialized transaction for the critical path (like toggle + count update only)
    const result = await serializedTransaction(async (tx) => {
      const existingLike = await tx.like.findUnique({
        where: {
          userId_targetId_targetType: {
            userId: auth.userId!,
            targetId,
            targetType,
          },
        },
        select: { id: true },
      });

      if (existingLike) {
        // Unlike - remove the like and decrement count in parallel
        const deleteOp = tx.like.delete({ where: { id: existingLike.id } });
        const countConfig = LIKES_COUNT_FIELDS[targetType];
        const countOp = countConfig
          ? (tx as any)[countConfig.model].update({
              where: { id: targetId },
              data: { [countConfig.field]: { decrement: 1 } },
            })
          : Promise.resolve();
        await Promise.all([deleteOp, countOp]);
        return { liked: false };
      } else {
        // Like - add the like and increment count in parallel
        const createOp = tx.like.create({
          data: {
            userId: auth.userId!,
            targetId,
            targetType,
          },
        });
        const countConfig = LIKES_COUNT_FIELDS[targetType];
        const countOp = countConfig
          ? (tx as any)[countConfig.model].update({
              where: { id: targetId },
              data: { [countConfig.field]: { increment: 1 } },
            })
          : Promise.resolve();
        await Promise.all([createOp, countOp]);
        return { liked: true };
      }
    });

    // Defer token/XP award and notification to background write queue (non-blocking for the response)
    if (result.liked) {
      const award = TOKEN_AWARDS[targetType];
      if (award) {
        const userId = auth.userId!;
        writeQueue.run(async () => {
          try {
            await db.tokenAction.create({
              data: {
                userId,
                action: award.action,
                targetId,
                tokensEarned: award.tokens,
                xpEarned: award.xp,
              },
            });
            await db.user.update({
              where: { id: userId },
              data: {
                auraTokens: { increment: award.tokens },
                auraXP: { increment: award.xp },
              },
            });
          } catch {
            // Token award is best-effort; if it fails (e.g., duplicate), skip silently
          }
        }).catch(() => {});
      }

      // Create notification for the content owner (non-blocking)
      const targetOwnerQuery: Record<string, () => Promise<{ ownerId: string; id: string } | null>> = {
        post: () => db.post.findUnique({ where: { id: targetId }, select: { authorId: true, id: true } }).then(p => p ? { ownerId: p.authorId, id: p.id } : null),
        reel: () => db.reel.findUnique({ where: { id: targetId }, select: { creatorId: true, id: true } }).then(r => r ? { ownerId: r.creatorId, id: r.id } : null),
        danceEntry: () => db.danceEntry.findUnique({ where: { id: targetId }, select: { authorId: true, id: true } }).then(e => e ? { ownerId: e.authorId, id: e.id } : null),
        hubPost: () => db.hubPost.findUnique({ where: { id: targetId }, select: { authorId: true, id: true } }).then(h => h ? { ownerId: h.authorId, id: h.id } : null),
      };

      const ownerQuery = targetOwnerQuery[targetType];
      if (ownerQuery) {
        writeQueue.run(async () => {
          try {
            const target = await ownerQuery();
            if (target && target.ownerId !== auth.userId) {
              const actionText = targetType === 'post' ? 'liked your post'
                : targetType === 'reel' ? 'liked your reel'
                : targetType === 'danceEntry' ? 'liked your dance entry'
                : 'liked your hub post';
              await db.notification.create({
                data: {
                  action: actionText,
                  type: 'like',
                  userId: target.ownerId,
                  triggeredByUserId: auth.userId,
                  thumbnail: '',
                },
              });
            }
          } catch {
            // Notification creation is best-effort
          }
        }).catch(() => {});
      }
    }

    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    console.error("Error toggling like:", error);
    return NextResponse.json(
      { success: false, error: "Failed to toggle like" },
      { status: 500 }
    );
  }
}

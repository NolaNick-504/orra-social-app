import { NextRequest, NextResponse } from "next/server";
import { db, serializedTransaction, writeQueue } from "@/lib/db";
import { getAuthUser, requireAuth } from "@/lib/auth-helpers";
import { writeFile, mkdir } from "fs/promises";
import { existsSync } from "fs";
import path from "path";
import crypto from "crypto";

export const dynamic = 'force-dynamic';

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");
// Fallback for standalone mode: also check project root
const PROJECT_UPLOAD_DIR = path.resolve(process.cwd(), "..", "..", "public", "uploads");

function getUploadDir(): string {
  // Use project root if running in standalone mode (cwd is .next/standalone/)
  if (existsSync(PROJECT_UPLOAD_DIR)) {
    return PROJECT_UPLOAD_DIR;
  }
  return UPLOAD_DIR;
}

const ALLOWED_IMAGE_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/gif",
  "image/webp",
]);

const ALLOWED_VIDEO_TYPES = new Set([
  "video/mp4",
  "video/webm",
  "video/quicktime",
]);

// GET /api/posts - Get feed posts (paginated)
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "10");
    const vibeTag = searchParams.get("vibeTag") || undefined;

    const currentUser = await getAuthUser();
    const skip = (page - 1) * limit;

    const where = vibeTag ? { vibeTag } : {};

    // Fetch current user's likes/saves/reposts in bulk (one query each instead of per-post sub-queries)
    let userLikes = new Set<string>();
    let userSaves = new Set<string>();
    let userReposts = new Set<string>();

    if (currentUser) {
      const [likes, saves, reposts] = await Promise.all([
        db.like.findMany({ where: { userId: currentUser.id, targetType: 'post' }, select: { targetId: true } }),
        db.save.findMany({ where: { userId: currentUser.id, targetType: 'post' }, select: { targetId: true } }),
        db.repost.findMany({ where: { userId: currentUser.id }, select: { postId: true } }),
      ]);
      userLikes = new Set(likes.map(l => l.targetId));
      userSaves = new Set(saves.map(s => s.targetId));
      userReposts = new Set(reposts.map(r => r.postId));
    }

    // Fetch posts without per-user sub-queries (much more efficient under concurrent load)
    const [posts, total] = await Promise.all([
      db.post.findMany({
        where,
        include: {
          author: {
            select: {
              id: true,
              name: true,
              handle: true,
              avatar: true,
              verified: true,
            },
          },
          poll: {
            include: {
              options: {
                include: {
                  votes: {
                    select: { id: true, userId: true },
                  },
                },
              },
            },
          },
          _count: {
            select: {
              comments: true,
              postLikes: true,
              postSaves: true,
              reposts: true,
            },
          },
        },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit,
      }),
      db.post.count({ where }),
    ]);

    // Use Set.has() for O(1) lookups instead of per-post sub-query results
    const postsWithMeta = posts.map((post) => {
      // Build poll data if present
      let pollData: {
        id: string;
        question: string;
        options: { id: string; text: string; voteCount: number; voted: boolean }[];
        totalVotes: number;
        expiresAt: Date;
      } | undefined = undefined;
      if (post.poll) {
        const totalVotes = post.poll.options.reduce(
          (sum, opt) => sum + opt.votes.length,
          0
        );
        pollData = {
          id: post.poll.id,
          question: post.poll.question,
          options: post.poll.options.map((opt) => ({
            id: opt.id,
            text: opt.text,
            voteCount: opt.votes.length,
            voted: currentUser
              ? opt.votes.some((v) => v.userId === currentUser.id)
              : false,
          })),
          totalVotes,
          expiresAt: post.poll.expiresAt,
        };
      }

      return {
        id: post.id,
        text: post.text,
        images: post.images,
        vibeTag: post.vibeTag,
        type: post.type,
        likesCount: post.likesCount,
        commentsCount: post.commentsCount,
        sharesCount: post.sharesCount,
        author: post.author,
        createdAt: post.createdAt,
        updatedAt: post.updatedAt,
        isLiked: currentUser ? userLikes.has(post.id) : false,
        isSaved: currentUser ? userSaves.has(post.id) : false,
        isReposted: currentUser ? userReposts.has(post.id) : false,
        _count: post._count,
        poll: pollData,
      };
    });

    return NextResponse.json({
      success: true,
      data: {
        posts: postsWithMeta,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error("Error fetching posts:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch posts" },
      { status: 500 }
    );
  }
}

// POST /api/posts - Create a new post (with optional file uploads as base64)
export async function POST(req: NextRequest) {
  try {
    const auth = await requireAuth();
    if (auth.response) return auth.response;

    const body = await req.json();
    const { text, images, vibeTag, type, uploadedFiles } = body;

    // Text is required for text/poll posts, but optional for image/video posts (caption is optional)
    const postTypeRequested = type || (images && images.length > 0 ? "image" : "text");
    if ((!text || text.trim().length === 0) && (postTypeRequested === 'text' || postTypeRequested === 'poll')) {
      return NextResponse.json(
        { success: false, error: "Post text is required" },
        { status: 400 }
      );
    }

    // Determine post type
    const postType = type || (images && images.length > 0 ? "image" : "text");

    // Process uploaded files (base64) if present
    let processedImageUrls: string[] = images || [];
    const uploadDir = getUploadDir();
    if (uploadedFiles && Array.isArray(uploadedFiles) && uploadedFiles.length > 0) {
      // Ensure upload directory exists
      if (!existsSync(uploadDir)) {
        await mkdir(uploadDir, { recursive: true });
      }

      for (const fileData of uploadedFiles) {
        const { data: base64Data, filename, contentType } = fileData;
        const isImage = ALLOWED_IMAGE_TYPES.has(contentType);
        const isVideo = ALLOWED_VIDEO_TYPES.has(contentType);

        if (!isImage && !isVideo) continue;

        // Extract raw base64 data (remove data:xxx;base64, prefix)
        const base64Match = base64Data.match(/^data:[^;]+;base64,(.+)$/);
        if (!base64Match) continue;

        const buffer = Buffer.from(base64Match[1], "base64");

        // Validate file size (10MB for images, 50MB for videos)
        const maxImageSize = 10 * 1024 * 1024;
        const maxVideoSize = 50 * 1024 * 1024;
        const maxSize = isImage ? maxImageSize : maxVideoSize;
        if (buffer.length > maxSize) {
          return NextResponse.json(
            { success: false, error: `File too large. Maximum size is ${isImage ? '10MB' : '50MB'}` },
            { status: 400 }
          );
        }

        // Generate unique filename
        // NOTE: sharp converts ALL images to JPEG, so always use .jpg for images
        // Keeping the original extension (e.g. .webp) after JPEG conversion causes browser rendering failures
        const ext = isImage ? ".jpg" : (path.extname(filename || "") || ".mp4");
        const safeFilename = `${crypto.randomUUID()}${ext}`;
        const filepath = path.join(uploadDir, safeFilename);

        if (isImage) {
          // Dynamic import sharp to avoid build-time issues
          const sharp = (await import("sharp")).default;
          await sharp(buffer)
            .resize({ width: 1200, withoutEnlargement: true })
            .jpeg({ quality: 80 })
            .toFile(filepath);
        } else {
          await writeFile(filepath, buffer);
        }

        processedImageUrls.push(`/uploads/${safeFilename}`);
      }
    }

    // Use serialized transaction for the critical path (post creation only)
    // Token/XP awards are deferred to avoid blocking the write queue
    const post = await serializedTransaction(async (tx) => {
      const newPost = await tx.post.create({
        data: {
          text: text ? text.trim() : "",
          images: JSON.stringify(processedImageUrls),
          vibeTag: vibeTag || "hyped",
          type: postType,
          authorId: auth.userId!,
        },
        include: {
          author: {
            select: {
              id: true,
              name: true,
              handle: true,
              avatar: true,
              verified: true,
            },
          },
        },
      });

      return newPost;
    });

    // Defer token/XP award to background write queue (non-blocking for the response)
    // This keeps the critical transaction short and fast
    // Post rewards: 5 tokens, 10 XP per post
    const userId = auth.userId!;
    const postId = post.id;
    writeQueue.run(async () => {
      try {
        await db.tokenAction.create({
          data: {
            userId,
            action: "post",
            targetId: postId,
            tokensEarned: 5,
            xpEarned: 10,
          },
        });
        await db.user.update({
          where: { id: userId },
          data: {
            auraTokens: { increment: 5 },
            auraXP: { increment: 10 },
          },
        });
      } catch {
        // Token award is best-effort; if it fails (e.g., duplicate), skip silently
      }
    }).catch(() => {});

    return NextResponse.json(
      { success: true, data: { ...post, isLiked: false, isSaved: false, isReposted: false, poll: null } },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error creating post:", error);
    return NextResponse.json(
      { success: false, error: "Failed to create post" },
      { status: 500 }
    );
  }
}

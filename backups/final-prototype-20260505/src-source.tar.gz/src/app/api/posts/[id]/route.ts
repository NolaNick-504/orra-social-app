import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getAuthUser, requireAuth } from "@/lib/auth-helpers";

// GET /api/posts/[id] - Get single post
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const currentUser = await getAuthUser();

    const post = await db.post.findUnique({
      where: { id },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            handle: true,
            avatar: true,
            verified: true,
          },
        },
        comments: {
          include: {
            author: {
              select: {
                id: true,
                name: true,
                handle: true,
                avatar: true,
                verified: true,
              },
            },
          },
          orderBy: { createdAt: "desc" },
          take: 50,
        },
        postLikes: currentUser
          ? {
              where: { userId: currentUser.id },
              select: { id: true },
            }
          : false,
        postSaves: currentUser
          ? {
              where: { userId: currentUser.id },
              select: { id: true },
            }
          : false,
        reposts: currentUser
          ? {
              where: { userId: currentUser.id },
              select: { id: true },
            }
          : false,
        _count: {
          select: {
            comments: true,
            postLikes: true,
            postSaves: true,
            reposts: true,
          },
        },
      },
    });

    if (!post) {
      return NextResponse.json(
        { success: false, error: "Post not found" },
        { status: 404 }
      );
    }

    const postWithMeta = {
      id: post.id,
      text: post.text,
      images: post.images,
      vibeTag: post.vibeTag,
      type: post.type,
      likesCount: post.likesCount,
      commentsCount: post.commentsCount,
      sharesCount: post.sharesCount,
      author: post.author,
      createdAt: post.createdAt,
      updatedAt: post.updatedAt,
      comments: post.comments,
      isLiked: currentUser ? post.postLikes?.length > 0 : false,
      isSaved: currentUser ? post.postSaves?.length > 0 : false,
      isReposted: currentUser ? post.reposts?.length > 0 : false,
      _count: post._count,
    };

    return NextResponse.json({ success: true, data: postWithMeta });
  } catch (error) {
    console.error("Error fetching post:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch post" },
      { status: 500 }
    );
  }
}

// DELETE /api/posts/[id] - Delete own post
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const auth = await requireAuth();
    if (auth.response) return auth.response;

    const { id } = await params;

    const post = await db.post.findUnique({
      where: { id },
      select: { authorId: true },
    });

    if (!post) {
      return NextResponse.json(
        { success: false, error: "Post not found" },
        { status: 404 }
      );
    }

    if (post.authorId !== auth.userId) {
      return NextResponse.json(
        { success: false, error: "You can only delete your own posts" },
        { status: 403 }
      );
    }

    await db.post.delete({ where: { id } });

    return NextResponse.json({ success: true, data: { message: "Post deleted" } });
  } catch (error) {
    console.error("Error deleting post:", error);
    return NextResponse.json(
      { success: false, error: "Failed to delete post" },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getAuthUser, requireAuth } from "@/lib/auth-helpers";

// GET /api/comments?postId=xxx - Get comments for a post
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const postId = searchParams.get("postId");

    if (!postId) {
      return NextResponse.json(
        { success: false, error: "postId query parameter is required" },
        { status: 400 }
      );
    }

    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "20");
    const skip = (page - 1) * limit;

    const currentUser = await getAuthUser();

    const [comments, total] = await Promise.all([
      db.comment.findMany({
        where: { postId },
        include: {
          author: {
            select: {
              id: true,
              name: true,
              handle: true,
              avatar: true,
              verified: true,
            },
          },
        },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit,
      }),
      db.comment.count({ where: { postId } }),
    ]);

    const commentsWithLikes = comments.map((comment) => ({
      ...comment,
      isLiked: false, // Could be enhanced to check likes on comments
    }));

    return NextResponse.json({
      success: true,
      data: {
        comments: commentsWithLikes,
        currentUserId: currentUser?.id || null,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error("Error fetching comments:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch comments" },
      { status: 500 }
    );
  }
}

// POST /api/comments - Add a comment
export async function POST(req: NextRequest) {
  try {
    const auth = await requireAuth();
    if (auth.response) return auth.response;

    const body = await req.json();
    const { postId, text } = body;

    if (!postId || !text || text.trim().length === 0) {
      return NextResponse.json(
        { success: false, error: "postId and text are required" },
        { status: 400 }
      );
    }

    // Check post exists
    const post = await db.post.findUnique({ where: { id: postId } });
    if (!post) {
      return NextResponse.json(
        { success: false, error: "Post not found" },
        { status: 404 }
      );
    }

    const comment = await db.$transaction(async (tx) => {
      const newComment = await tx.comment.create({
        data: {
          text: text.trim(),
          postId,
          authorId: auth.userId!,
        },
        include: {
          author: {
            select: {
              id: true,
              name: true,
              handle: true,
              avatar: true,
              verified: true,
            },
          },
        },
      });

      // Increment comments count on the post
      await tx.post.update({
        where: { id: postId },
        data: { commentsCount: { increment: 1 } },
      });

      // Award +5 tokens + 10 XP for commenting (anti-farming check)
      const existingAction = await tx.tokenAction.findUnique({
        where: {
          userId_action_targetId: {
            userId: auth.userId!,
            action: "comment",
            targetId: newComment.id,
          },
        },
      });

      if (!existingAction) {
        await tx.tokenAction.create({
          data: {
            userId: auth.userId!,
            action: "comment",
            targetId: newComment.id,
            tokensEarned: 2,
            xpEarned: 5,
          },
        });

        await tx.user.update({
          where: { id: auth.userId },
          data: {
            auraTokens: { increment: 2 },
            auraXP: { increment: 5 },
          },
        });
      }

      return newComment;
    });

    // Create notification for post author
    if (post.authorId !== auth.userId) {
      await db.notification.create({
        data: {
          action: "commented on your post",
          type: "comment",
          userId: post.authorId,
          triggeredByUserId: auth.userId,
        },
      }).catch(() => {
        // Non-critical: notification creation failure shouldn't break the request
      });
    }

    return NextResponse.json(
      { success: true, data: comment },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error creating comment:", error);
    return NextResponse.json(
      { success: false, error: "Failed to create comment" },
      { status: 500 }
    );
  }
}

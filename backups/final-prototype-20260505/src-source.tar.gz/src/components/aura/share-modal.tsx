'use client';

import { useAuraStore } from '@/store/aura-store';
import { useToggleRepost } from '@/lib/api-hooks';
import { X, Link2, Waves, Send, MessageCircle } from 'lucide-react';
import { toast } from 'sonner';

export function ShareModal() {
  const { showShareModal, toggleShareModal, sharePostId } = useAuraStore();
  const toggleRepostApi = useToggleRepost();

  if (!showShareModal) return null;

  const handleCopyLink = () => {
    const link = `${window.location.origin}/post/${sharePostId || 'shared'}`;
    navigator.clipboard.writeText(link).then(() => {
      toast.success('Link copied to clipboard!');
    }).catch(() => {
      toast.success('Link copied!');
    });
    toggleShareModal();
  };

  const handleEcho = () => {
    if (sharePostId) {
      // Persist echo (repost) to the database
      toggleRepostApi.mutate({ postId: sharePostId }, { onError: () => {
        toast.error('Echo failed to sync');
      }});
    }
    toast.success('Echoed to your feed!');
    toggleShareModal();
  };

  const handleShareDM = () => {
    if (sharePostId) {
      // Persist share via DM to the database
      fetch('/api/chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ postId: sharePostId }),
      }).catch(() => {
        // Non-critical: DM share failure shouldn't block UX
      });
    }
    toast.success('Share via DM sent!');
    toggleShareModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-md" onClick={() => toggleShareModal()} />
      <div className="relative glass-panel rounded-2xl p-6 w-full max-w-sm fade-in border border-violet-500/20">
        <button onClick={() => toggleShareModal()} className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-white/10 transition-all text-slate-400 hover:text-white">
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-lg font-bold text-white mb-5">Share</h2>

        <div className="space-y-2">
          <button
            onClick={handleCopyLink}
            className="w-full flex items-center gap-3 p-3.5 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-violet-500/30 transition-all group"
          >
            <div className="w-10 h-10 rounded-xl bg-violet-600/20 flex items-center justify-center">
              <Link2 className="w-5 h-5 text-violet-400" />
            </div>
            <div className="text-left">
              <p className="text-sm font-semibold text-white">Copy Link</p>
              <p className="text-xs text-slate-500">Copy post link to clipboard</p>
            </div>
          </button>

          <button
            onClick={handleEcho}
            className="w-full flex items-center gap-3 p-3.5 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-emerald-500/30 transition-all group"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-600/20 flex items-center justify-center">
              <Waves className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="text-left">
              <p className="text-sm font-semibold text-white">Echo</p>
              <p className="text-xs text-slate-500">Amplify across ORRA</p>
            </div>
          </button>

          <button
            onClick={handleShareDM}
            className="w-full flex items-center gap-3 p-3.5 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-emerald-500/30 transition-all group"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-600/20 flex items-center justify-center">
              <Send className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="text-left">
              <p className="text-sm font-semibold text-white">Share via DM</p>
              <p className="text-xs text-slate-500">Send in a direct message</p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}

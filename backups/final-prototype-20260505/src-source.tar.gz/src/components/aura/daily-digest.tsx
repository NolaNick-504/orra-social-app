'use client';

import { useAuraStore } from '@/store/aura-store';
import { useCurrentUser } from '@/lib/use-current-user';
import { usePosts, useNotifications } from '@/lib/api-hooks';
import { X, Sun, Zap, TrendingUp, Users, Heart, Sparkles, ArrowRight, Crown, Flame, Coffee, Clock } from 'lucide-react';
import { useMemo } from 'react';

export function DailyDigest() {
  const { showDigest, dismissDigest, auraTokens, auraLevel, dailyStreak, userSettings, setView, setViewingUser, setView: navigateTo } = useAuraStore();
  const currentUser = useCurrentUser();
  const { data: postsData } = usePosts();
  const { data: notifData } = useNotifications();

  // Only show if enabled in settings and digest hasn't been dismissed today
  if (!showDigest || !userSettings.digestEnabled) return null;

  // Greeting based on time of day
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';
  const greetingIcon = hour < 12 ? <Coffee className="w-5 h-5 text-amber-400" /> : <Sun className="w-5 h-5 text-amber-400" />;

  // Compute digest data
  const posts = postsData?.posts || [];
  const trendingPosts = useMemo(() =>
    [...posts].sort((a, b) => b.likesCount - a.likesCount).slice(0, 3),
    [posts]
  );

  const unreadNotifs = notifData?.unreadCount || 0;
  const firstName = currentUser.name.split(' ')[0];

  // Token progress
  const tokenGrowth = Math.min(auraTokens * 0.02, 50); // Simulated % growth

  // Time until next level
  const xpProgress = useAuraStore.getState().auraXP;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/70 backdrop-blur-md" onClick={dismissDigest} />

      {/* Digest Card */}
      <div className="relative w-full max-w-lg fade-in">
        {/* Holographic glow border effect */}
        <div className="absolute -inset-[1px] rounded-2xl bg-gradient-to-r from-violet-600 via-fuchsia-500 to-cyan-400 opacity-60 animate-pulse blur-[1px]" />
        <div className="relative glass-panel rounded-2xl overflow-hidden border border-violet-500/30">
          {/* Header */}
          <div className="relative px-6 pt-6 pb-4">
            <button onClick={dismissDigest} className="absolute top-4 right-4 p-1.5 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition-all">
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-3">
              <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br from-violet-600/30 to-fuchsia-600/30 border border-violet-500/30">
                {greetingIcon}
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">{greeting}, {firstName}</h2>
                <p className="text-xs text-slate-400">Your ORRA Digest — {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}</p>
              </div>
            </div>

            {/* Streak Badge */}
            {dailyStreak > 0 && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/20">
                <Flame className="w-4 h-4 text-amber-400" />
                <span className="text-sm font-bold text-amber-300">{dailyStreak} Day Streak</span>
                <span className="text-[10px] text-amber-400/60 ml-auto">Keep it going!</span>
              </div>
            )}
          </div>

          {/* Token Summary */}
          <div className="mx-6 p-4 rounded-xl bg-gradient-to-br from-amber-500/10 via-violet-500/10 to-fuchsia-500/10 border border-amber-500/20">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                <span className="text-sm font-bold text-white">Token Balance</span>
              </div>
              <span className="text-lg font-black text-amber-400">{auraTokens.toLocaleString()} ORRA</span>
            </div>
            <div className="flex items-center justify-between text-[10px]">
              <span className="text-slate-400">Level {auraLevel}</span>
              <span className="text-emerald-400 flex items-center gap-0.5">
                <TrendingUp className="w-3 h-3" />
                {tokenGrowth.toFixed(1)}% this week
              </span>
            </div>
            <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden mt-2">
              <div className="h-full bg-gradient-to-r from-amber-500 to-violet-500 rounded-full" style={{ width: `${(xpProgress / 1000) * 100}%` }} />
            </div>
          </div>

          {/* Trending Pulses */}
          <div className="px-6 pt-4 pb-2">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-violet-400" />
                <span className="text-sm font-bold text-white">Trending Pulses</span>
              </div>
              <button onClick={() => { dismissDigest(); navigateTo('explore'); }} className="text-[10px] text-violet-400 hover:text-violet-300 flex items-center gap-0.5">
                View all <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {trendingPosts.length > 0 ? (
              <div className="space-y-2">
                {trendingPosts.map((post, i) => (
                  <div key={post.id} className="flex items-start gap-3 p-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-all cursor-pointer group">
                    <span className="text-lg font-black text-violet-500/50 w-6 text-center flex-shrink-0">{i + 1}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-semibold text-white truncate">{post.author.name}</span>
                        {post.author.verified && <Crown className="w-3 h-3 text-violet-400" />}
                      </div>
                      <p className="text-xs text-slate-300 line-clamp-2 mt-0.5">{post.text}</p>
                    </div>
                    <div className="flex items-center gap-1 text-[10px] text-slate-500 flex-shrink-0">
                      <Heart className="w-3 h-3" /> {post.likesCount}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-white/5 text-center">
                <p className="text-xs text-slate-500">No trending pulses yet — be the first to post!</p>
              </div>
            )}
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-2 px-6 pt-2 pb-4">
            <div className="text-center p-2.5 rounded-xl bg-white/5">
              <Users className="w-4 h-4 text-violet-400 mx-auto mb-1" />
              <p className="text-sm font-bold text-white">{unreadNotifs}</p>
              <p className="text-[9px] text-slate-500">New Activity</p>
            </div>
            <div className="text-center p-2.5 rounded-xl bg-white/5">
              <Sparkles className="w-4 h-4 text-fuchsia-400 mx-auto mb-1" />
              <p className="text-sm font-bold text-white">{auraLevel}</p>
              <p className="text-[9px] text-slate-500">ORRA Level</p>
            </div>
            <div className="text-center p-2.5 rounded-xl bg-white/5">
              <Flame className="w-4 h-4 text-amber-400 mx-auto mb-1" />
              <p className="text-sm font-bold text-white">{dailyStreak}</p>
              <p className="text-[9px] text-slate-500">Day Streak</p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="px-6 pb-6 flex gap-2">
            <button
              onClick={dismissDigest}
              className="flex-1 px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sm font-semibold text-slate-300 hover:bg-white/10 hover:border-violet-500/30 transition-all"
            >
              Later
            </button>
            <button
              onClick={() => { dismissDigest(); }}
              className="flex-1 px-4 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white text-sm font-bold hover:opacity-90 transition-all glow-violet flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              Start My Day
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
